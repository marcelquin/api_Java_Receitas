package baseAPI.API.Sistema.AbstractFactory.Factory;


public interface ContaBanco {

    public Double Saque(Double valor);

    public Double Deposito(Double valor);

}
