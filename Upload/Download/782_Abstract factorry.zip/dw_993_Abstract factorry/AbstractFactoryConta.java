package baseAPI.API.Sistema.AbstractFactory.Factory;


public interface AbstractFactoryConta{

    ContaBanco criar(int tipo);
}
