package baseAPI.API.Sistema.DTO;

import lombok.Data;

@Data
public class PacoteDTO {

    private String nome;

    private String descrisao;
}
