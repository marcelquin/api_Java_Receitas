package baseAPI.API.Sistema.Generic.Model;

import baseAPI.API.Sistema.Generic.Generic.BaseEntity;
import jakarta.persistence.Entity;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@Data
public class ContaCorrente extends BaseEntity {


}
